PNEUMO FORMELN – ANDROID APK PROJEKT

Dieses Projekt enthält die Android-WebView-App und die offline eingebettete Pneumo-Formeln-HTML-Datei.
Der AaDO2-Rechner wurde auf konsistente Feldnamen korrigiert.

APK-Build vom Handy aus:
1. ZIP entpacken.
2. Auf GitHub ein neues Repository erstellen.
3. Alle Dateien und Ordner aus diesem Projekt in das Repository hochladen (einschließlich .github/workflows/build-apk.yml).
4. Im Repository den Tab „Actions“ öffnen.
5. Den Workflow „Build Android APK“ auswählen und „Run workflow“ antippen.
6. Nach erfolgreichem Build den Workflow-Lauf öffnen, unten das Artefakt „Pneumo-Formeln-APK“ herunterladen.
7. ZIP öffnen und app-debug.apk installieren. Android kann nach der Erlaubnis „Unbekannte Apps installieren“ fragen.

Hinweise:
- Der Debug-Build ist für die private Installation auf dem eigenen Android-Gerät geeignet.
- Für eine Veröffentlichung im Play Store wäre eine signierte Release-Version mit eigenem Schlüssel nötig.
- Die App enthält die HTML-Rechnerdatei lokal und benötigt für die Berechnungen keine Internetverbindung.
- Die medizinischen Inhalte/Formeln müssen vor klinischer Anwendung fachlich validiert werden.
